package eseat;

import javafx.collections.transformation.TransformationList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.stage.Stage;
import javafx.stage.Window;
import javafx.event.ActionEvent;

import java.io.IOException;


public class Bus_routeController {
    @FXML
    private RadioButton rb1;

    @FXML
    private RadioButton rb2;

    @FXML
    private RadioButton rb3;

    @FXML
    private RadioButton rb4;

    @FXML
    private RadioButton rb5;

    @FXML
    private Button confirm;

    public void setConfirm(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("payment.fxml"));
        Scene payment = new Scene(root);
       // Scene paymentController = new Scene(root);


        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
                window.setScene(payment);
        //window.setScene(payment);
                window.show();


//        Main m = new Main ();
//       m.changeScene(login.fxml);


    
    }
}


