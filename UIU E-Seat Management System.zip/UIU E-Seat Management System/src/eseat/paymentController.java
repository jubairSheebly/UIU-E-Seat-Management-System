package eseat;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.stage.Stage;

import java.io.IOException;

public class paymentController {

    @FXML
    private RadioButton bkash;

    @FXML
    private RadioButton card;

    @FXML
    private RadioButton cod;

    @FXML
    private Button done;

    @FXML
    private ToggleGroup payment;

    @FXML
    void switchbutton(ActionEvent event) throws IOException {

        Parent login = FXMLLoader.load(getClass().getResource("shatolBus.fxml"));

        Scene Mainwindow = new Scene(login);

        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();

        window.setScene(Mainwindow);
        window.show();


    }

}